/**
 * Provides utility classes for the connection to Exchange.
 */
package com.archibus.app.reservation.exchange.util;