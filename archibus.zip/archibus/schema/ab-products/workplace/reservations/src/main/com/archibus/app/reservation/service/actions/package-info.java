/**
 * Defines a number of actions that can be applied to the repeated occurrences of a recurrence
 * pattern, used in the reservations module.
 */
package com.archibus.app.reservation.service.actions;