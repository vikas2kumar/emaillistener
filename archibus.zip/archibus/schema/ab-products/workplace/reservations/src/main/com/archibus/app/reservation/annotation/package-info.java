/**
 * Provides annotations for Archibus.
 */
package com.archibus.app.reservation.annotation;

