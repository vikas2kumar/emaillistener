/**
 * Provides interfaces for datasources for reservation module.
 */
package com.archibus.app.reservation.dao;
