/**
 * Provides classes and interfaces for utilities.
 */
package com.archibus.app.reservation.util;