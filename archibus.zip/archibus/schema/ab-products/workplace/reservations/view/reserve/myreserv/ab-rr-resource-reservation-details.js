var reservationDetailsController = View.createController("reservationDetailsController", {
	
	afterInitialDataFetch: function() {
	},  
    
    onDwgLoaded: function(){ 
    },
    
    roomPanel_afterRefresh: function() {
    }
 
});