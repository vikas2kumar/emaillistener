/**
 * Controller for viewing room reservations.
 */
var reservationSelectController = View.extendController("reservationSelectController", reservationSelectControllerBase, {
	
	/** Create Reservation View */
	createReservationView: "ab-rr-create-room-reservation.axvw",
	
	/** Reservation Details View */
	reservationDetailsView: "ab-rr-room-reservation-details.axvw",
	
	/** Name of the virtual location field in the grid */
	locationProperty: "reserve_rm.room",
	
	/** Name of the WFR to cancel multiple reservations */
	cancelMultipleWfr: "AbWorkplaceReservations-roomReservationService-cancelMultipleRoomReservations",
	
	/** Name of the WFR to cancel a single reservation */
	cancelSingleWfr: "AbWorkplaceReservations-roomReservationService-cancelRoomReservation",
	
	/** Name of the WFR to cancel a recurring reservation */
	cancelRecurringWfr: "AbWorkplaceReservations-roomReservationService-cancelRecurringRoomReservation",
	
	/** Name of the WFR to copy a reservation */
	copyWfr: "AbWorkplaceReservations-roomReservationService-copyRoomReservation",
	
	/** Building id field name for the rows in the grid */
	buildingIdFieldName: "reserve_rm.bl_id",
	
	/**
	 * Check whether the room reservation can be cancelled / edited based on
	 * restrictions in the room arrangement.
	 */
	checkRoom: function(row, startDate, now, daysDifference) {
		var editButton = row.actions.get('edit');
		var cancelButton = row.actions.get('cancel'); 
		var cancelDays = parseInt(row.getFieldValue('rm_arrange.cancel_days'));
		var announceDays = parseInt(row.getFieldValue('rm_arrange.announce_days'));
		var maxDaysAhead = parseInt(row.getFieldValue('rm_arrange.max_days_ahead'));
		
		var cancelTime = row.getFieldValue('rm_arrange.cancel_time');
		cancelTime.setFullYear(now.getFullYear());
		cancelTime.setMonth(now.getMonth());
		cancelTime.setDate(now.getDate());
		
		var announceTime = row.getFieldValue('rm_arrange.announce_time');
		announceTime.setFullYear(now.getFullYear());
		announceTime.setMonth(now.getMonth());
		announceTime.setDate(now.getDate());	
         // check for conditions for cancelling date and time
    	 if (daysDifference < cancelDays) { 
    		 cancelButton.forceDisable(true);
    	 } else if (daysDifference == cancelDays && now > cancelTime) { 	 
    		 cancelButton.forceDisable(true);
    	 } else {
    		 cancelButton.forceDisable(false);
    	 }

    	 // check for conditions for edit date and time
    	 var maxDaysAheadOK = View.user.isMemberOfGroup('RESERVATION ASSISTANT')
    	 	|| View.user.isMemberOfGroup('RESERVATION SERVICE DESK')
    	 	|| View.user.isMemberOfGroup('RESERVATION MANAGER')
    	 	|| daysDifference <= maxDaysAhead;
    	 if (daysDifference < announceDays || !maxDaysAheadOK) {
    		 editButton.forceDisable(true);
    	 } else	 if (daysDifference == announceDays && now > announceTime) {	 
    		 editButton.forceDisable(true);
    	 } else {
    		 editButton.forceDisable(false);  
    	 }
	}
	
});

