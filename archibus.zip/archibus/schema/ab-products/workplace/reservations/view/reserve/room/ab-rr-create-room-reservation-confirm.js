/**
* Room Reservation Confirmation controller.
* <p>
* Controller is used when creating a room reservation.
* <p>
*
* @author Bart Vanderschoot
* @since 21.2
*/
var reservationConfirmController = View.extendController('reservationConfirmController', reservationConfirmBaseController, {
	
	/** name of the tab to return to after confirmation */
	selectTabName: "selectRoomReservation",
	
	/**
	 * Get the building id.
	 */
	getBuildingId: function() {
		return this.reserveRoomPanel.getFieldValue("reserve_rm.bl_id");
	},
	
	/**
	 * Get the floor id.
	 */
	getFloorId: function() {
		return this.reserveRoomPanel.getFieldValue("reserve_rm.fl_id");
	},
	
	/**
	 * Get the room id.
	 */
	getRoomId: function() {
		return this.reserveRoomPanel.getFieldValue("reserve_rm.rm_id");
	},
	
	/**
	 * Fetch the location from the opener view and store it in this view.
	 */
	fetchLocation: function() {
		var reserveRoomPanel = View.getOpenerView().panels.get("reserveRoomPanel");
		reserveRoomPanel.fields.each(function(field) {
            var value = field.getUIValue();
            if (value != null) {
                this.reserveRoomPanel.setFieldValue(field.getFullName(), value); 
            }
	    }, this);
		
		var roomLocation = this.getBuildingId() + "-" + this.getFloorId() + "-" + this.getRoomId();
		$("roomLocation").innerHTML = roomLocation;
	},
	
	/**
	 * Retrieve the actual cost from the server.
	 * Calls the WFR without error handling.
	 * @return WFR result
	 */
	callCostWfr: function(reservation, caterings, resources, numberOfOccurrences) {
		var roomAllocation = this.reserveRoomPanel.getOutboundRecord();
		return Workflow.callMethod("AbWorkplaceReservations-roomReservationService-calculateTotalCost", 
					reservation, roomAllocation, caterings, resources, numberOfOccurrences);
	},
	
	/**
	 * Validate the confirmation form before submitting.
	 * To override.
	 * @return true if valid, false otherwise
	 */
	validateForSubmit: function() {
		var validated = this.reservePanel.canSave();
		if (validated) {
			// If valid, update the date and time of the room panel (hidden).
			var dateStart = this.reservePanel.getFieldValue("reserve.date_start");
			var timeStart = this.reservePanel.getFieldValue("reserve.time_start");
			var timeEnd = this.reservePanel.getFieldValue("reserve.time_end");
			
			this.reserveRoomPanel.setFieldValue("reserve_rm.date_start", dateStart); 
			this.reserveRoomPanel.setFieldValue("reserve_rm.time_start", timeStart);
			this.reserveRoomPanel.setFieldValue("reserve_rm.time_end", timeEnd);
		}
		return validated;
	},
	
	/**
	 * Call the WFR for submitting the reservation (error handling is up to the caller).
	 * To override
	 * @return WFR result
	 */
	callSubmitWfr: function(reservation, caterings, resources) {
		var roomAllocation = this.reserveRoomPanel.getOutboundRecord();
		return Workflow.callMethod("AbWorkplaceReservations-roomReservationService-saveRoomReservation",
				reservation, roomAllocation, resources, caterings);
	}

});