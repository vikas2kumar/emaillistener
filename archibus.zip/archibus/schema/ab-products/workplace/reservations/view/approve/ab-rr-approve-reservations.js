var abRrApproveReservationsController = View.createController('abRrApproveReservationsController', {
});
